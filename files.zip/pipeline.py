"""CAC 40 – pipeline séries temporelles. Usage : python pipeline.py  ->  écrit data.json
pip install yfinance pandas numpy scipy statsmodels arch
"""
import json, warnings, datetime as dt
import numpy as np, pandas as pd, yfinance as yf
from scipy import stats
from statsmodels.tsa.stattools import adfuller, kpss, coint
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.api import VAR
from statsmodels.tsa.vector_ar.vecm import VECM, coint_johansen
from statsmodels.stats.diagnostic import acorr_ljungbox, het_arch
from arch import arch_model

warnings.filterwarnings("ignore")
START = "2010-01-01"

# ---------- 1. Données mensuelles ----------
def yf_m(t):
    s = yf.download(t, start=START, interval="1mo", auto_adjust=True, progress=False)["Close"].squeeze()
    s.index = s.index.to_period("M")
    return s[~s.index.duplicated(keep="last")]

ecb = pd.read_csv("https://fred.stlouisfed.org/graph/fredgraph.csv?id=ECBDFR", index_col=0, parse_dates=True).squeeze()
ecb = pd.to_numeric(ecb, errors="coerce").dropna()
ecb = ecb.groupby(ecb.index.to_period("M")).last()

df = pd.concat({"cac": yf_m("^FCHI"), "brent": yf_m("BZ=F"), "fx": yf_m("EURUSD=X"), "rate": ecb}, axis=1).dropna()
df = df[df.index < pd.Period(dt.date.today(), "M")]          # on retire le mois en cours (incomplet)

L = np.column_stack([np.log(df.cac), np.log(df.brent), np.log(df.fx), df.rate])   # niveaux (log pour les prix)
R = np.column_stack([100 * np.diff(L[:, :3], axis=0), np.diff(L[:, 3])])            # rendements % + Δtaux
V = R                                   # colonnes : rCAC, rBrent, rFX, Δtaux
y, E = V[1:, 0], V[:-1, 1:]             # E[t] = infos du mois t-1 (connues quand on prévoit t)
Vv, Ll = V[1:], L                       # alignement pour VAR / VECM
n = len(y)

# ---------- 2. Stationnarité ----------
def tests(name, x):
    a, k = adfuller(x, autolag="AIC"), kpss(x, regression="c", nlags="auto")
    ok_a, ok_k = a[1] < .05, k[1] > .05
    v = "stationnaire" if ok_a and ok_k else "non stationnaire" if not ok_a and not ok_k else "ambigu"
    return dict(name=name, adf_stat=a[0], adf_p=a[1], kpss_stat=k[0], kpss_p=k[1], verdict=v)

names = ["CAC 40 (log)", "Brent (log)", "EUR/USD (log)", "Taux BCE (niveau)"]
rn = ["Rendement CAC 40", "Rendement Brent", "Rendement EUR/USD", "Δ Taux BCE"]
tst = [tests(nm, L[:, i]) for i, nm in enumerate(names)] + [tests(nm, V[:, i]) for i, nm in enumerate(rn)]

# ---------- 3. Cointégration ----------
jo = coint_johansen(L, det_order=0, k_ar_diff=1)
rank = 0
for lr, cv in zip(jo.lr1, jo.cvt[:, 1]):
    if lr > cv: rank += 1
    else: break
rank = min(rank, 3)
eg_p = coint(L[:, 0], L[:, 1:], trend="c")[1]
co_text = (f"Johansen : rang {rank}. Engle-Granger p = {eg_p:.3f}. " +
           ("Une relation de long terme existe : le VECM est testé en plus du VAR en rendements."
            if rank > 0 else "Pas de relation de long terme détectée : on modélise les rendements (séries différenciées), sans terme à correction d'erreur."))

# ---------- 4. Modèles ----------
def best_order(yy):
    best, bo = 1e18, (0, 0, 0)
    for p in range(3):
        for q in range(3):
            try:
                a = ARIMA(yy, order=(p, 0, q)).fit().aic
                if a < best: best, bo = a, (p, 0, q)
            except Exception: pass
    return bo

def fit(name, yy, EE, VV, e_next, LL, order):
    if name == "mean": return yy.mean(), yy - yy.mean()
    if name == "zero": return 0.0, yy
    if name == "arima":
        r = ARIMA(yy, order=order).fit(); return r.forecast(1)[0], r.resid
    if name == "arimax":
        r = ARIMA(yy, exog=EE, order=(1, 0, 0)).fit(); return r.forecast(1, exog=e_next)[0], r.resid
    if name == "var":
        r = VAR(VV).fit(1); return r.forecast(VV[-1:], 1)[0, 0], r.resid[:, 0]
    if name == "vecm":
        r = VECM(LL, k_ar_diff=1, coint_rank=rank).fit(); return 100 * (r.predict(steps=1)[0, 0] - LL[-1, 0]), r.resid[:, 0]

labels = {"mean": "Moyenne historique (benchmark)", "zero": "Marche aléatoire (0 %)", "arima": "ARIMA (ordre par AIC)",
          "arimax": "ARIMAX (Brent, EUR/USD, Δtaux retardés)", "var": "VAR(1) sur rendements", "vecm": "VECM"}
keys = ["mean", "zero", "arima", "arimax", "var"] + (["vecm"] if rank > 0 else [])

# ---------- 5. Backtest walk-forward (fenêtre extensible, aucune fuite d'information) ----------
start = int(0.6 * n)
P = {k: [] for k in keys}; order = (1, 0, 0)
for i, t in enumerate(range(start, n)):
    if i % 12 == 0: order = best_order(y[:t])
    for k in keys:
        try: P[k].append(fit(k, y[:t], E[:t], Vv[:t], E[t:t + 1], Ll[:t + 2], order)[0])
        except Exception: P[k].append(P["mean"][-1] if P["mean"] else 0.0)
act = y[start:]
e_mean = act - np.array(P["mean"])
rows = []
for k in keys:
    p_ = np.array(P[k]); e = act - p_
    d = e_mean ** 2 - e ** 2
    rows.append(dict(key=k, label=labels[k], rmse=float(np.sqrt(np.mean(e ** 2))), mae=float(np.mean(abs(e))),
                     hit=None if k == "zero" else float(np.mean(np.sign(p_) == np.sign(act))),
                     oos_r2=float(1 - np.sum(e ** 2) / np.sum(e_mean ** 2)),
                     dm_p=None if k == "mean" else float(stats.ttest_1samp(d, 0).pvalue)))
best = min(rows, key=lambda r: r["rmse"])["key"]

# ---------- 6. Prévision finale + diagnostics ----------
order = best_order(y)
mu, resid = fit(best, y, E, Vv, V[-1, 1:].reshape(1, -1), Ll, order)
g = arch_model(V[:, 0], mean="Constant", vol="GARCH", p=1, q=1, dist="t").fit(disp="off")
sig, nu = float(np.sqrt(g.forecast(horizon=1).variance.values[-1, 0])), float(g.params["nu"])
q = lambda a: stats.t.ppf(1 - (1 - a) / 2, nu) * np.sqrt((nu - 2) / nu)
last = float(df.cac.iloc[-1]); lv = lambda r: float(last * np.exp(r / 100))
fc = dict(date=str(df.index[-1] + 1), ret=float(mu), level=lv(mu), sigma=sig, model=labels[best],
          i80=[lv(mu - q(.8) * sig), lv(mu + q(.8) * sig)], i95=[lv(mu - q(.95) * sig), lv(mu + q(.95) * sig)])
diag = dict(lb_p=float(acorr_ljungbox(resid, lags=[12])["lb_pvalue"].iloc[0]), arch_p=float(het_arch(resid, nlags=12)[1]),
            jb_p=float(stats.jarque_bera(resid)[1]))

out = dict(generated=str(dt.date.today()), source="Yahoo Finance (^FCHI, BZ=F, EURUSD=X), FRED (ECBDFR)", n=n,
           sample=[str(df.index[0]), str(df.index[-1])], last_date=str(df.index[-1]), last_level=last,
           history=[[str(i), float(v)] for i, v in zip(df.index, df.cac)], tests=tst,
           coint=dict(rank=rank, eg_p=float(eg_p), text=co_text), models=rows, best=best,
           backtest=dict(dates=[str(df.index[t + 2]) for t in range(start, n)], actual=act.tolist(),
                         best=[float(v) for v in P[best]], mean=[float(v) for v in P["mean"]]),
           forecast=fc, diag=diag, arima_order=list(order))
json.dump(out, open("data.json", "w"), ensure_ascii=False, default=float)
print("OK -> data.json | modèle retenu :", labels[best], "| prévision", fc["date"], round(fc["level"], 1))
