const $ = (id) => document.getElementById(id);
const f = (x, d = 2) => x == null ? '–' : Number(x).toLocaleString('fr-FR', { minimumFractionDigits: d, maximumFractionDigits: d });
const p = (x) => x == null ? '–' : x < 0.001 ? '< 0,001' : f(x, 3);

document.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('.tab, .panel').forEach((el) => el.classList.remove('active'));
  b.classList.add('active');
  $(b.dataset.tab).classList.add('active');
}));

const tag = (v) => `<span class="tag ${v === 'stationnaire' ? 'ok' : v === 'ambigu' ? '' : 'ko'}">${v}</span>`;
const line = (label, data, color, extra = {}) => ({ label, data, borderColor: color, backgroundColor: color, borderWidth: 2, pointRadius: 0, tension: 0, ...extra });

function render(d) {
  const fc = d.forecast;
  $('f-label').textContent = `CAC 40 prévu – ${fc.date}`;
  $('f-level').textContent = f(fc.level, 0);
  $('f-last').textContent = `Dernier point : ${f(d.last_level, 0)} (${d.last_date})`;
  $('f-ret').textContent = `${f(fc.ret)} %`;
  $('f-80').textContent = `${f(fc.i80[0], 0)} – ${f(fc.i80[1], 0)}`;
  $('f-95').textContent = `${f(fc.i95[0], 0)} – ${f(fc.i95[1], 0)}`;
  $('f-model').textContent = `Modèle retenu : ${fc.model}. Écart-type mensuel prévu (GARCH) : ${f(fc.sigma)} %.`;
  $('source').textContent = `${d.source} · généré le ${d.generated}`;

  const h = d.history.slice(-36), n = h.length;
  const labels = [...h.map((x) => x[0]), fc.date];
  const pad = (v) => [...Array(n - 1).fill(null), h[n - 1][1], v];
  new Chart($('c-hist'), { type: 'line', data: { labels, datasets: [
    line('CAC 40', [...h.map((x) => x[1]), null], '#00796b'),
    line('Prévision', pad(fc.level), '#c2410c', { borderDash: [6, 4], pointRadius: 4 }),
    line('IC 95 % haut', pad(fc.i95[1]), 'rgba(194,65,12,.35)', { fill: '+1', borderWidth: 0, spanGaps: true }),
    line('IC 95 % bas', pad(fc.i95[0]), 'rgba(194,65,12,.35)', { borderWidth: 0, spanGaps: true }),
  ] }, options: { maintainAspectRatio: false, interaction: { mode: 'index', intersect: false }, plugins: { legend: { labels: { filter: (i) => !i.text.startsWith('IC') } } } } });

  $('t-stat').innerHTML = d.tests.map((t) => `<tr><td>${t.name}</td><td class="num">${f(t.adf_stat)}</td><td class="num">${p(t.adf_p)}</td><td class="num">${f(t.kpss_stat)}</td><td class="num">${p(t.kpss_p)}</td><td>${tag(t.verdict)}</td></tr>`).join('');
  $('t-coint').textContent = d.coint.text;

  $('t-models').innerHTML = d.models.map((m) => `<tr class="${m.key === d.best ? 'best' : ''}"><td>${m.label}</td><td class="num">${f(m.rmse)}</td><td class="num">${f(m.mae)}</td><td class="num">${m.hit == null ? '–' : f(m.hit * 100, 0) + ' %'}</td><td class="num">${f(m.oos_r2 * 100, 1)} %</td><td class="num">${p(m.dm_p)}</td></tr>`).join('');
  const b = d.models.find((m) => m.key === d.best);
  const sig = b.dm_p != null && b.dm_p < 0.05 && b.oos_r2 > 0;
  $('bt-note').textContent = b.key === 'mean' || b.key === 'zero'
    ? 'Aucun modèle ne bat le benchmark hors échantillon : le CAC 40 mensuel est ici statistiquement imprévisible avec ces variables.'
    : sig ? `${b.label} bat significativement le benchmark (p = ${p(b.dm_p)}).`
          : `${b.label} a la meilleure erreur, mais l'écart avec le benchmark n'est pas significatif (p = ${p(b.dm_p)}) : à interpréter avec prudence.`;

  const bt = d.backtest;
  new Chart($('c-bt'), { type: 'line', data: { labels: bt.dates, datasets: [
    line('Réalisé', bt.actual, '#17202a', { borderWidth: 1.5 }),
    line('Modèle retenu', bt.best, '#c2410c'),
    line('Moyenne historique', bt.mean, '#00796b', { borderDash: [5, 4] }),
  ] }, options: { maintainAspectRatio: false, interaction: { mode: 'index', intersect: false } } });

  const dg = d.diag;
  const rows = [['Ljung-Box (12 retards) : autocorrélation', dg.lb_p, 'p > 0,05 : résidus sans autocorrélation'],
                ['ARCH-LM (12 retards) : hétéroscédasticité', dg.arch_p, 'p < 0,05 : volatilité groupée, d\'où le GARCH'],
                ['Jarque-Bera : normalité', dg.jb_p, 'p < 0,05 : queues épaisses, d\'où la loi de Student']];
  $('t-diag').innerHTML = rows.map(([a, v, c]) => `<tr><td>${a}</td><td class="num">${p(v)}</td><td>${c}</td></tr>`).join('');
  $('m-meta').textContent = `${d.n} observations mensuelles (${d.sample[0]} à ${d.sample[1]}). ARIMA candidat : ordre (${d.arima_order.join(',')}).`;
}

fetch('data.json').then((r) => r.json()).then(render).catch(() => { $('f-level').textContent = 'data.json introuvable'; });
